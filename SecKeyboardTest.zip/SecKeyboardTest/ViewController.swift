//
//  ViewController.swift
//  SecKeyboardTest
//
//  Created by AnJeongHyun on 2016. 2. 17..
//  Copyright © 2016년 sam. All rights reserved.
//

import UIKit

class ViewController: UIInputViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate  {
    
    
    var keyboardView : MyCustomView!
    var newImage : UIImage!
    
    @IBAction func ClickedCamera(sender: UIButton) {

    }
    @IBAction func ClickedElbum(sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary;
            imagePicker.allowsEditing = true
            self.presentViewController(imagePicker, animated: true, completion: nil)
        }

    }
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        let theInfo:NSDictionary = info as NSDictionary
        
        let img:UIImage = theInfo.objectForKey(UIImagePickerControllerOriginalImage) as! UIImage
        
        NSKeyedArchiver.archiveRootObject(img, toFile: "bg_img3.png")
        let screenSize: CGRect = UIScreen.mainScreen().bounds
        let imageView = UIImageView(frame: CGRectMake(0,0,screenSize.width,screenSize.height/3)); // set as you want
        self.dismissViewControllerAnimated(true, completion: nil)
        imageView.image = img
        newImage = img
        self.view.addSubview(imageView)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

